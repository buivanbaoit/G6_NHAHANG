﻿using G6_WebsiteNhaHang.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace G6_WebsiteNhaHang.Areas.Admin.Controllers
{
    public class AdminLoginController : Controller
    {
        public NHAHANGDBEntities db = new NHAHANGDBEntities();


        // GET: Admin/Admin
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(string username,string password)
        {
            string pass = EnCode.EnCodeMD5(password);
            var result = db.Administrative.Where(s => s.UserName.Equals(username) && s.PassWord.Equals(pass)).FirstOrDefault();
            if (result != null)
            {
                Session["admin"] = result.Adminid;
                return RedirectToAction("Index", "AdminHome");
            }
            else
            {
                return View();
            }
        }
        public ActionResult Logout()
        {
            Session["admin"] = null;
            Session.Abandon();
            return RedirectToAction("Login", "AdminHome");
        }

    }
}