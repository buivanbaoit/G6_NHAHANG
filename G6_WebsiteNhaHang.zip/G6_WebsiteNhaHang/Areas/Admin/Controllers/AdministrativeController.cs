﻿using G6_WebsiteNhaHang.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace G6_WebsiteNhaHang.Areas.Admin.Controllers
{
    public class AdministrativeController : Controller
    {
        public NHAHANGDBEntities db = new NHAHANGDBEntities();
       

        // GET: Admin/Administrative
        public ActionResult Index()
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Administrative.ToList();
            return View(model);
        }
        public ActionResult create()
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            //ViewBag.types = new SelectList(db.ProductType.ToList(), "Id", "Name");
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult create(Administrative administrative, HttpPostedFileBase images)
        {

            if (images != null & images.ContentLength > 0)
            {
                administrative.Image = images.FileName;
                string UrlImage = Server.MapPath("~/Content/images/" + administrative.Image);
                images.SaveAs(UrlImage);
            }
            if (ModelState.IsValid)
            {
                administrative.PassWord = EnCode.EnCodeMD5(administrative.PassWord);
                //db.Product.GetType(Da) = DateTime.Now;
                db.Administrative.Add(administrative);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            //ViewBag.listTypes = new SelectList(db.ProductType, "Id", "Name", product.ProductType);
            return View(administrative);
        }

        ////////////////////////////////
        public ActionResult Edit(int Id)
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Administrative.Find(Id);
            //ViewBag.types = new SelectList(db.ProductType.ToList(), "Id", "Name", model.TypeId);
            return View(model);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Edit(Administrative administrative, HttpPostedFileBase newImages)
        {
            if (newImages != null && newImages.ContentLength > 0)
            {
                administrative.Image = newImages.FileName;
                string Image = Server.MapPath("~/Content/images/" + administrative.Image);
                newImages.SaveAs(Image);
            }
            if (ModelState.IsValid)
            {
                administrative.PassWord = EnCode.EnCodeMD5(administrative.PassWord);
                db.Entry(administrative).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Administrative");
            }
            return View(administrative);
        }
        /////////////////////////////////////
        public ActionResult Details(int Id)
        {

            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Administrative.Find(Id);
            return View(model);
        }
        ////////////////////////////////
        public ActionResult Delete(int Id)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var model = db.Administrative.Find(Id);
            return View(model);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult AcepDelete(int Id)
        {
            var administrative = db.Administrative.Find(Id);
            db.Administrative.Remove(administrative);
            db.SaveChanges();
            return RedirectToAction("Index", "Administrative");
        }
    }
}