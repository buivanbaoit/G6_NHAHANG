﻿using G6_WebsiteNhaHang.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace G6_WebsiteNhaHang.Areas.Admin.Controllers
{
    public class CustommerController : Controller
    {
        public NHAHANGDBEntities db = new NHAHANGDBEntities();
        // GET: Admin/Custommer
        public ActionResult Index()
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Customer.ToList();
            return View(model);
        }

        public ActionResult Edit(int Id)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var model = db.Customer.Find(Id);
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(Customer customer)
        {
            if (ModelState.IsValid)
            {
                customer.Password = EnCode.EnCodeMD5(customer.Password);
                db.Entry(customer).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Custommer");
            }
            return View(customer);
        }
        public ActionResult create()
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            //ViewBag.types = new SelectList(db.ProductType.ToList(), "Id", "Name");
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult create(Customer customer)
        {
            if (ModelState.IsValid)
            {
                //db.Product.GetType(Da) = DateTime.Now;
                customer.Password = EnCode.EnCodeMD5(customer.Password);
                db.Customer.Add(customer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            //ViewBag.listTypes = new SelectList(db.ProductType, "Id", "Name", product.ProductType);
            return View(customer);
        }

      
        public ActionResult Details(int Id)
        {

            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Customer.Find(Id);
            return View(model);
        }
        ////////////////////////////////
        public ActionResult Delete(int Id)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var model = db.Customer.Find(Id);
            return View(model);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult AcepDelete(int Id)
        {
            var custommer = db.Customer.Find(Id);
            db.Customer.Remove(custommer);
            db.SaveChanges();
            return RedirectToAction("Index", "Custommer");
        }
    }
}