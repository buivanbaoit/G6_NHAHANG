﻿using G6_WebsiteNhaHang.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace G6_WebsiteNhaHang.Areas.Admin.Controllers
{
    public class OderController : Controller
    {
        public NHAHANGDBEntities db = new NHAHANGDBEntities();
        public ActionResult Index()
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Order.ToList();
            return View(model);
        }
        public ActionResult Detail(int id)
        {
            ViewBag.Od = db.Order.Find(id);
            var model = db.OrderDetail.Where(p => p.OrderId == id).ToList();
            return View(model);
        }
        public ActionResult Edit(int id)
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Order.Find(id);
            model.Id = (int)Session["admin"];
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(Order order)
        {
            if (ModelState.IsValid)
            {
                db.Entry(order).State = EntityState.Modified;
                db.SaveChanges();
            }
            return RedirectToAction("Index", "Oder");
        }
    }
    
}