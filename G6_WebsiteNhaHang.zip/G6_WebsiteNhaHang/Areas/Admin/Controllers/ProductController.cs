﻿using G6_WebsiteNhaHang.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Reflection;
using PagedList.Mvc;
using PagedList;

namespace G6_WebsiteNhaHang.Areas.Admin.Controllers
{
    public class ProductController : Controller
    {
        public NHAHANGDBEntities db = new NHAHANGDBEntities();
        

        // GET: Admin/Product
        public ActionResult Index()
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var models = db.Product.OrderByDescending(p => p.Id).ToList();
            return View(models);
        }
        //public ActionResult page(int? size, int? page)
        //{


        //    // 1. Tạo list pageSize để người dùng có thể chọn xem để phân trang
        //    // Bạn có thể thêm bớt tùy ý --- dammio.com
        //    List<SelectListItem> items = new List<SelectListItem>();
        //    items.Add(new SelectListItem { Text = "5", Value = "5" });
        //    items.Add(new SelectListItem { Text = "10", Value = "10" });
        //    items.Add(new SelectListItem { Text = "20", Value = "20" });
        //    items.Add(new SelectListItem { Text = "25", Value = "25" });
        //    items.Add(new SelectListItem { Text = "50", Value = "50" });
        //    items.Add(new SelectListItem { Text = "100", Value = "100" });
        //    items.Add(new SelectListItem { Text = "200", Value = "200" });
        //    // 1.1. Giữ trạng thái kích thước trang được chọn trên DropDownList
        //    foreach (var item in items)
        //    {
        //        if (item.Value == size.ToString()) item.Selected = true;
        //    }

        //    // 1.2. Tạo các biến ViewBag
        //    ViewBag.size = items; // ViewBag DropDownList
        //    ViewBag.currentSize = size; // tạo biến kích thước trang hiện tại

        //    // 2. Nếu page = null thì đặt lại là 1.
        //    page = page ?? 1; //if (page == null) page = 1;

        //    // 3. Tạo truy vấn, lưu ý phải sắp xếp theo trường nào đó, ví dụ OrderBy
        //    // theo LinkID mới có thể phân trang.
        //    var links = (from l in db.Product
        //                 select l).OrderBy(x => x.Id);

        //    // 4. Tạo kích thước trang (pageSize), mặc định là 5.
        //    int pageSize = (size ?? 5);

        //    // 4.1 Toán tử ?? trong C# mô tả nếu page khác null thì lấy giá trị page, còn
        //    // nếu page = null thì lấy giá trị 1 cho biến pageNumber.
        //    int pageNumber = (page ?? 1);
        //    // 5. Trả về các Link được phân trang theo kích thước và số trang.
        //    return View(Product.ToPagedList(pageNumber, pageSize));
        //}

        public ActionResult searrch(string searchString)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var ss = from l in db.Product // lấy toàn bộ liên kết
                     select l;

            if (!String.IsNullOrEmpty(searchString)) // kiểm tra chuỗi tìm kiếm có rỗng/null hay không
            {
                ss = ss.Where(s => s.Name.Contains(searchString)); //lọc theo chuỗi tìm kiếm
            }

            return View(ss);
            //var models = db.Product.OrderByDescending(p => p.Id).ToList();
            //return View(models);
        }
        
        public ActionResult create()
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            ViewBag.types = new SelectList(db.ProductType.ToList(), "Id", "Name");
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult create(Product product, HttpPostedFileBase images)
        {

            if (images != null & images.ContentLength > 0)
            {
                product.ImageUrl = images.FileName;
                string UrlImage = Server.MapPath("~/Content/images/" + product.ImageUrl);
                images.SaveAs(UrlImage);
            }
            if (ModelState.IsValid)
            {

                //db.Product.GetType(Da) = DateTime.Now;
                db.Product.Add(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.listTypes = new SelectList(db.ProductType, "Id", "Name", product.ProductType);
            return View(product);
        }
        public ActionResult Details(int Id)
        {

            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Product.Find(Id);
            return View(model);
        }
        public ActionResult Delete(int id)
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Product.Find(id);
            return View(model);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult AcepDelete(int id)
        {
            var product = db.Product.Find(id);
            var OrderDetail = db.OrderDetail.ToList();
            int checks = 0;
            foreach(OrderDetail i in OrderDetail)
            {
                if (id == i.ProductId)
                {
                    checks = checks + 1;
                }
            }
            if(checks > 0)
            {
                TempData["checks"] = "Product này đã tồn tại trong chi tiết hóa đơn, vui lòng xóa tại chi tiết hóa đơn trước khi xóa tour";
                return RedirectToAction("Delete", "Product");
            }
            else{
                db.Product.Remove(product);
                db.SaveChanges();
                TempData["checks"] = "Bạn đã xóa Product thành công";
                return RedirectToAction("Index", "Product");
            }
            //db.Product.Remove(product);
            //db.SaveChanges();
            //return RedirectToAction("Index", "Product");
        }
        ////////////////////////////////////////////////////////
        public ActionResult Edit(int id)
        {
            if (Session["admin"] == null)
                return RedirectToAction("Index", "AdminLogin");
            var model = db.Product.Find(id);
            ViewBag.types = new SelectList(db.ProductType.ToList(), "Id", "Name", model.TypeId);
            return View(model);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Edit(Product product, HttpPostedFileBase newImages)
        {
            if (newImages != null && newImages.ContentLength > 0)
            {
                product.ImageUrl = newImages.FileName;
                string Image = Server.MapPath("~/Content/images/" + product.ImageUrl);
                newImages.SaveAs(Image);
            }
            if (ModelState.IsValid)
            {
                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Product");
            }
            ViewBag.listTypes = new SelectList(db.ProductType, "Id", "Name", product.TypeId);
            return View(product);
        }
       
    }
}