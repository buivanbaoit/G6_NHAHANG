﻿using G6_WebsiteNhaHang.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace G6_WebsiteNhaHang.Areas.Admin.Controllers
{
    public class ProductTypeController : Controller
    {
        public NHAHANGDBEntities db = new NHAHANGDBEntities();


        // GET: Admin/ProductType
        public ActionResult Index()
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var models = db.ProductType.ToList();
            return View(models);
        }
        public ActionResult Create()
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            return View();
        }
        [HttpPost]
        public ActionResult Create(ProductType type)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            try
            {
                db.ProductType.Add(type); //Add or Update Book b
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult Details(int Id)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var model = db.ProductType.Find(Id);
            return View(model);
        }
        public ActionResult Delete(int Id)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var model = db.ProductType.Find(Id);
            return View(model);
        }
        [HttpPost,ActionName("Delete")]
        public ActionResult AcepDelete(int Id)
        {
            var item = db.ProductType.Find(Id);
            db.ProductType.Remove(item);
            db.SaveChanges();
            return RedirectToAction("Index", "ProductType");
        }
        public ActionResult Edit(int Id)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("Index", "AdminLogin");
            }
            var model = db.ProductType.Find(Id);
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(ProductType productType)
        {
            if (ModelState.IsValid)
            {
                db.Entry(productType).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "ProductType");
            }
            return View(productType);
        }
    }
}   