﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using G6_WebsiteNhaHang.Models;



namespace G6_WebsiteNhaHang.Controllers
{
    public class CartController : Controller
    {
        public NHAHANGDBEntities db = new NHAHANGDBEntities();
        // GET: Cart
        public ActionResult Index()
        {
            ViewBag.menu = db.ProductType.ToList();
            List<Cartitem> list = (List<Cartitem>)Session["cartSession"];

            return View(list);
        }
        public ActionResult AddItem(int id)
        {
            ViewBag.menu = db.ProductType.ToList();
            var cart = Session["cartSession"];
            List<Cartitem> list = new List<Cartitem>();
            //cart is null
            if(cart == null)
            {
                Product product = db.Product.Where(x => x.Id == id).SingleOrDefault();
                Cartitem item = new Cartitem();
                item.product = product;
                item.quantity = 1;
                list.Add(item);
                Session["cartSession"] = list;
            }
            else
            {
                list = (List<Cartitem>)Session["cartSession"];
                if(list.Exists(x =>x.product.Id == id))
                {
                    foreach(var a in list)
                    {
                        if (a.product.Id == id)
                            a.quantity = a.quantity + 1;
                    }
                    Session["cartSession"] = list;
                }
                else
                {
                   Product product = db.Product.Where(x => x.Id==id ).SingleOrDefault();
                    Cartitem item = new Cartitem();
                    item.product = product;
                    item.quantity = 1;
                    list.Add(item);
                    Session["cartSession"] = list;
                }
            }
            return RedirectToAction("Index","Cart");
        }
        public ActionResult Updateitem(int id,int quantity)
        {
            ViewBag.menu = db.ProductType.ToList();
            List<Cartitem> list = (List<Cartitem>)Session["cartSession"];
            if (quantity != 0)
            {
                list.Where(p => p.product.Id.Equals(id)).FirstOrDefault().quantity = quantity;
                
            }
            return RedirectToAction("Index", "Cart");
        }
        public ActionResult Deleteitem(int id)
        {
            ViewBag.menu = db.ProductType.ToList();
            List<Cartitem> list = (List<Cartitem>)Session["cartSession"];
            Cartitem item = list.Where(p => p.product.Id.Equals(id)).FirstOrDefault();
            list.Remove(item);
            Session["cartSession"] = list;
            return RedirectToAction("Index", "Cart");
        }

        public ActionResult Order()
        {
            if (Session["Customer"] == null)
            {
                ViewBag.menu = db.ProductType.ToList();
                return RedirectToAction("Index", "Login");
            }
            else
            {
                //OrderProduct
              
                    Order od = new Order();
                    od.Id = db.Order.OrderByDescending(p => p.Id).First().Id + 1;
                    od.Date = DateTime.Now;
                    od.CustomerId = (int)Session["Customer"];
                    od.Status = 1;
                    od.ShippingType = "";
                    //od.IsTableReservation = true;
                    od.Note = "khong";
                    db.Order.Add(od);
                    db.SaveChanges();
                    //Customer ct = db.Customer.Find(od.CustomerId);
                    //send customer
                List<Cartitem> list = (List<Cartitem>)Session["cartSession"];
                string message = "";
                float sum = 0;
            foreach (Cartitem item in list)
            {
                    
                    OrderDetail orderDetail = new OrderDetail();
                    Product product = new Product();
                    orderDetail.OrderId = od.Id;
                    orderDetail.ProductId = item.product.Id;
                    orderDetail.Count = item.quantity;
                    orderDetail.Price =((double?)(item.quantity *item.product.Price));
                    db.OrderDetail.Add(orderDetail);

                    db.SaveChanges();
                    message += "<br/><h1> DANH SÁCH ĐẶT HÀNG - BMT-RESTAURENT ";
                    message += "<br/> MENU: " + item.product.Id;
                    message += "<br/> Tên Món Ăn: " + item.product.Name;
                    message += "<br/> Số Lượng: " + item.quantity;
                    message += "<br/> Giá Tiền: " + item.product.Price;
                    message += "<br/> Số lượng x Giá: " + String.Format("{0:0,0 VND}", item.quantity * item.product.Price);
                    sum += (float)(item.quantity * item.product.Price);

                }
                message += "<br /> Tổng tiền cần thanh toán: " + string.Format("{0:0,0 VND}", sum);
                od.SumPrice = (double)sum;
                db.SaveChanges();
                //send customer

                Customer st = db.Customer.Find(od.CustomerId);
                SendMail(st.Email, "G6-RESTAURENT", message);
                Session["cartSession"] = null;
                return RedirectToAction("Index", "Home");

            }
        }

        public void SendMail(string address, string subject,string message)
        {
            string email = "buivanbaosp@gmail.com";
            string password = "Roy9999B";

            var loginInfo = new NetworkCredential(email, password);
            var msg = new MailMessage();
            var smtp = new SmtpClient("smtp.gmail.com", 587);

            msg.From = new MailAddress(email);
            msg.To.Add(new MailAddress(address));
            msg.Subject = subject;
            msg.Body = message;
            msg.IsBodyHtml = true;
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = loginInfo;
            smtp.Send(msg);
        }
        //SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
        //SmtpServer.Port = 587;
        //SmtpServer.Credentials = new System.Net.NetworkCredential("buivanbaosp@gmail.com", "Roy9999B");

        //private static readonly string _from = ""; // Email của Sender (của bạn)
        //private static readonly string _pass = ""; // Mật khẩu Email của Sender (của bạn)

        //public static string Send(string sendto, string subject, string content)
        //{
        //    //sendto: Email receiver (người nhận)
        //    //subject: Tiêu đề email
        //    //content: Nội dung của email, bạn có thể viết mã HTML
        //    //Nếu gửi email thành công, sẽ trả về kết quả: OK, không thành công sẽ trả về thông tin l�-i
        //    try
        //    {
        //        MailMessage mail = new MailMessage();
        //        SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

        //        mail.From = new MailAddress(_from);
        //        mail.To.Add(sendto);
        //        mail.Subject = subject;
        //        mail.IsBodyHtml = true;
        //        mail.Body = content;

        //        mail.Priority = MailPriority.High;

        //        SmtpServer.Port = 587;
        //        SmtpServer.Credentials = new System.Net.NetworkCredential(_from, _pass);
        //        SmtpServer.EnableSsl = true;

        //        SmtpServer.Send(mail);
        //        return "OK";
        //    }
        //    catch (Exception ex)
        //    {
        //        return ex.ToString();
        //    }

        //}
    }
}