﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using G6_WebsiteNhaHang.Models;
using PagedList;
using System.Net.Mail;
using System.Net;

namespace G6_WebsiteNhaHang.Controllers
{
    public class HomeController : Controller
    {
        public NHAHANGDBEntities db = new NHAHANGDBEntities();
        public IEnumerable<Product> AllListPaging(int page, int pageSize)
        {
            return db.Product.OrderByDescending(x => x.Name).ToPagedList(page, pageSize);
        }
        public IEnumerable<Product> AllListPagingByType(int page, int pageSize, string TypeID)
        {
            int ma = int.Parse(TypeID);
            return db.Product.OrderByDescending(x => x.Name).Where(x => x.TypeId == ma).ToPagedList(page, pageSize);
        }

        public ActionResult Index(string id, int page = 1, int pageSize = 20)
        {

            ViewBag.menu = db.ProductType.ToList();

            if (id == null)
            {
                var model = AllListPaging(page, pageSize);
                ViewBag.id = null;
                return View(model);
            }
            else
            {
                int ma = int.Parse(id);
                var model = AllListPagingByType(page, pageSize, id);
                ViewBag.id = id;
                return View(model);
            }
        }

        public ActionResult About()
        {
            ViewBag.menu = db.ProductType.ToList();
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.menu = db.ProductType.ToList();
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Details(int id)
        {
            ViewBag.menu = db.ProductType.ToList();
            var model = db.Product.Find(id);
            return View(model);
        }
        public ActionResult Service()
        {
            ViewBag.menu = db.ProductType.ToList();
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult SendMail()
        {
            return View();

        }
        public ActionResult HistoryOrder()
        {
            ViewBag.menu = db.ProductType.ToList();
            if (Session["customer"] == null)
                return RedirectToAction("Index", "login");
            int cusId = (int)Session["customer"];
            var models = db.Order.Where(p => p.CustomerId == cusId).OrderBy(p => p.Date).ToList();
            return View(models);
        }
        public ActionResult DetailOD(int id)
        {
            ViewBag.Od = db.Order.Find(id);
            var model = db.OrderDetail.Where(p => p.OrderId == id).ToList();
            return View(model);
        }


        // [HttpPost]
        // public ActionResult SendMail(EmailModel model)
        // {
        //     using (MailMessage mm = new MailMessage(model.Email, model.To))
        //     {
        //         mm.Subject = model.Subject;
        //         mm.Body = model.Body;
        //         if (model.Attachment.ContentLength > 0)
        //         {
        //             string fileName = Path.GetFileName(model.Attachment.FileName);
        //             mm.Attachments.Add(new Attachment(model.Attachment.InputStream, fileName));
        //         }
        //         mm.IsBodyHtml = false;
        //         using (SmtpClient smtp = new SmtpClient())
        //         {
        //             smtp.Host = "buivanbaosp.gmail.com";
        //             smtp.EnableSsl = true;
        //             NetworkCredential NetworkCred = new NetworkCredential(model.Email, model.PassWord);
        //             smtp.UseDefaultCredentials = true;
        //             smtp.Credentials = NetworkCred;
        //             smtp.Port = 587;
        //             smtp.Send(mm);
        //             ViewBag.Message = "Email sent.";
        //         }
        //     }
        //
        //     return View();
        // }
    }
}

