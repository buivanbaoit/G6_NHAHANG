﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using G6_WebsiteNhaHang.Models;

namespace G6_WebsiteNhaHang.Controllers
{
    public class LoginController : Controller
    {

        public NHAHANGDBEntities db = new NHAHANGDBEntities();
        // GET: Login
        public ActionResult Index()
        {
            ViewBag.menu = db.ProductType.ToList();
            return View();
        }
        

    
        [HttpPost]
        public ActionResult Index(string UserName, string Password)
        {
            ViewBag.menu = db.ProductType.ToList();
            string pass = EnCode.EnCodeMD5(Password);
            var rs = db.Customer.Where(p => p.UserName.Equals(UserName) && p.Password.Equals(pass)).FirstOrDefault();
            if(rs != null)
            {
                Session["Customer"] = rs.Id;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.error = "Login failed";
                return RedirectToAction("Index", "Login");
            }
        }
        public ActionResult Regiter()
        {
            //ViewBag.menu = db.ProductType.ToList();
            return View();
        }
        [HttpPost]
        public ActionResult Regiter(Customer customer)
        {
            if (ModelState.IsValid)
            {
                //ViewBag.menu = db.ProductType.ToList();

                customer.Password = EnCode.EnCodeMD5(customer.Password);
                //customer.Id = db.Customer.OrderByDescending(u => u.Id).FirstOrDefault().Id + 1;
                db.Customer.Add(customer);
                db.SaveChanges();
            }
            return RedirectToAction("Index", "Home");
        }
    }
}