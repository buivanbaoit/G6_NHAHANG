﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using G6_WebsiteNhaHang.Models;

namespace G6_WebsiteNhaHang.Models
{
    public class Cartitem
    {
        public Product product { get; set; }
        public int quantity { get;set; }

    }
}