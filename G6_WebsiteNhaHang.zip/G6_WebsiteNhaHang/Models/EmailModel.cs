﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;

namespace G6_WebsiteNhaHang.Models
{
    public class EmailModel
    {
        public string To{ get; set; }
        public string Subject{ get; set; }
        public string Body { get; set; }
        public HttpPostedFileBase Attachment { get; set; }
        public string Email { get; set; }
        public string PassWord { get; set; }


    }
}
